<?php

session_start();


//Konekcija
require_once("db.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Oglasi za posao</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="css/AdminLTE.min.css">
  <link rel="stylesheet" href="css/_all-skins.min.css">
  <link rel="stylesheet" href="css/custom.css">

  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
		 <style>
  body {
    font: 400 15px Lato, sans-serif;
    line-height: 1.8;
    color: #818181;
  }
  
  
  .panel-heading {
    color: #fff !important;
    background-color: #f4511e !important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }

  .panel {
    border: 5px solid 
#ff7878
	; 
    border-radius:0 !important;
    transition: box-shadow 0.5s;
	
  }
  .panel:hover {
    box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
    border: 1px solid #3b3131;
    background-color: #fff !important;
    color: #f4511e;
  }
  .panel-heading {
    color: #fff !important;
    background-color: 
#ffbaba
!important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  .panel-footer {
    background-color: white !important;
  }
  .img-circle {
  display: block;
  margin-left: 315px;
  margin-right: auto;
  width: 70%;
}
  .panel-footer h3 {
    font-size: 32px;
  }
  .panel-footer h4 {
    color: #3b3131;
    font-size: 14px;
  }
  .panel-footer .btn {
    margin: 15px 0;
    background-color: #f4511e;
    color: #ffffff;
  }
  .navbar {
    margin-bottom: 0;
    background-color: #f4511e;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
    color: #f4511e !important;
    background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
  }

  }
  </style>
</head>
<body class="hold-transition skin-red sidebar-mini">
<div class="wrapper">


<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
       <header class="main-header">
	 <a class="navbar-brand" href="index.php">Oglasi za posao</a>
	 
   
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="jobs.php">POSLOVI</a></li>
        <li><a href="#candidates">KANDIDATI</a></li>
        <li><a href="#company">POSLODAVCI</a></li>
        <li><a href="#about">O NAMA</a></li>
 
  
          <?php if(empty($_SESSION['id_user']) && empty($_SESSION['id_company'])) { ?>
          <li>
            <a href="login.php"><span class="glyphicon glyphicon-user"></span><b>Login</b></a>
          </li>
          <li>
            <a href="sign-up.php"><b>Sign Up</b></a>
          </li>  
          <?php } else { 

            if(isset($_SESSION['id_user'])) { 
          ?>        
          <li>
            <a href="user/index.php">Profil</a>
          </li>
          <?php
          } else if(isset($_SESSION['id_company'])) { 
          ?>        
          <li>
            <a href="company/index.php">Profil</a>
          </li>
          <?php } ?>
          <li>
            <a href="logout.php"><b>Logout</b></a>
          </li>
          <?php } ?>
		  
		      
      </ul>
    </div>
  </div>
</nav>
  
  </header>

  <!-- Vrep -->
  <div class="content-wrapper" style="margin-left: 0px;">

    <section class="content-header bg-main">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center index-head">
            <h1><strong>MESTO ZA ZAPOSLJAVANJE U SRBIJI</strong></h1>
            <p><a class="btn btn-info btn-lg" href="jobs.php" role="button">Pretraži poslove</a></p>
          </div>
        </div>
      </div>
    </section>

    <section class="content-header">
      <div class="container">
        <div class="row">
          <div class="col-md-12 latest-job margin-bottom-20">
		  
            <h1 class="text-center"><strong>Istaknuti poslovi</strong></h1>            
            <?php 
          $sql = "SELECT * FROM job_post Order By Rand() Limit 3";
          $result = $conn->query($sql);
          if($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) 
            {
              $sql1 = "SELECT * FROM company WHERE id_company='$row[id_company]'";
              $result1 = $conn->query($sql1);
              if($result1->num_rows > 0) {
                while($row1 = $result1->fetch_assoc()) 
                {
             ?>
			 <div id="pricing" class="container-fluid">

			 <div class="row slideanim">
				<div class="col-sm-4 col-xs-12">
					<div class="panel panel-default text-center">
			<div class="panel-heading">
          <h2><a href="view-job-post.php?id=<?php echo $row['id_jobpost']; ?>"><?php echo $row['jobtitle']; ?></a> </h2>
			</div>
        
                 <div class="panel-body">
          <img class="attachment-img" height="190" width="200" src="uploads/logo/<?php echo $row1['logo']; ?>" alt="Attachment Image">
                   <p><strong><?php echo $row1['companyname']; ?> | <?php echo $row1['city']; ?> - sediste kompanije | Iskustvo: <?php echo $row['experience']; ?> godine</strong></p>

        </div>
	<div class="panel-footer">
          <strong><h4><?php echo $row['maximumsalary']; ?> rsd mesecno</strong></h4>
		   <p class="bg-danger"><strong><h4><?php echo $row['rok']; ?> je rok prijave</strong></p></h4>
		  <strong><h4><?php echo $row['lokacija']; ?></strong></h4>
		
          
        </div>
              </div>
            </div>
          <?php
              }
            }
            }
          }
          ?>
          </div>
        </div>
      </div>
    </section>



	

    <section id="candidates" class="content-header">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center latest-job margin-bottom-20">
            <h1>Kandidati</h1>
            <p>Nalaženje posla je upravo postalo lakše. Kreirajte profil i prijavite se jednim klikom.</p>            
          </div>
        </div>
        <div class="row">
          <div class="col-sm-4 col-md-4 well" >
            <div class="thumbnail candidate-img">
              <img src="img/job.jpg" class="img-circle" height="80" width="40" alt="Trazi posao">
              <div class="caption">
                <h3 class="text-center">Pretraži poslove</h3>
              </div>
            </div>
          </div>
          <div class="col-sm-4 col-md-4 well">
            <div class="thumbnail candidate-img ">
              <img src="img/jjj.jpg"  class="img-circle" height="80" width="40"alt="Prijavi se">
              <div class="caption">
                <h3 class="text-center">Prijavi se za intervju</h3>
              </div>
            </div>
          </div>
          <div class="col-sm-4 col-md-4 well">
            <div class="thumbnail candidate-img">
              <img src="img/karijera.jpg"  class="img-circle"height="80" width="40" alt="Pokreni karijeru">
              <div class="caption">
                <h3 class="text-center">Pokreni svoju karijeru</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="company" class="content-header">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center latest-job margin-bottom-20">
            <h1>Poslodavci</h1>
                 
          </div>
        </div>
        <div class="row">
          <div class="col-sm-3 col-md-3">
            <div class="thumbnail company-img">
              <img src="img/sa.png" alt="Postavite oglas">
            
            </div>
          </div>
          <div class="col-lg-3 col-lg-3">
            <div class="thumbnail company-img">
              <img src="img/inter.jpg" alt="Apply & Get Interviewed">
             
            </div>
          </div>
          <div class="col-lg-3 col-lg-3">
            <div class="thumbnail company-img">
              <img src="img/bosch.jpg" alt="Start A Career">
             
            </div>
          </div>
		  <div class="col-lg-3 col-lg-3">
            <div class="thumbnail company-img">
              <img src="img/zfg.jpg" alt="Career">
              
            </div>
          </div>
		  <div class="col-lg-3 col-lg-3">
            <div class="thumbnail company-img">
              <img src="img/mer.jpg" alt="A Career">
             
            </div>
          </div>
		    <div class="col-lg-3 col-lg-3">
            <div class="thumbnail company-img">
              <img src="img/uni.jpg" alt="Career2">
             
            </div>
          </div>
		    <div class="col-lg-3 col-lg-3">
            <div class="thumbnail company-img">
              <img src="img/mts.jpg" alt="A2 Career">
            
            </div>
          </div>
		  		    <div class="col-lg-3 col-lg-3">
            <div class="thumbnail company-img">
              <img src="img/a1.jpg" alt="A1 Career">
              <div class="caption">
               
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

 
    <section id="statistics" class="content-header">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center latest-job margin-bottom-20">
            <h1>Statistika</h1>
          </div>
        </div>
        <div class="row">
        <div class="col-lg-4 col-xs-7 well">
          <!-- mala kutija -->
          <div class="small-box bg-aqua">
            <div class="inner">
             <?php
                      $sql = "SELECT * FROM job_post";
                      $result = $conn->query($sql);
                      if($result->num_rows > 0) {
                        $totalno = $result->num_rows;
                      } else {
                        $totalno = 0;
                      }
                    ?>
              <h3><?php echo $totalno; ?></h3>

              <p>Oglasi</p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-paper"></i>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-xs-7 well">
          <!-- mala kutija -->
          <div class="small-box bg-green">
            <div class="inner">
                  <?php
                      $sql = "SELECT * FROM company WHERE active='1'";
                      $result = $conn->query($sql);
                      if($result->num_rows > 0) {
                        $totalno = $result->num_rows;
                      } else {
                        $totalno = 0;
                      }
                    ?>
              <h3><?php echo $totalno; ?></h3>

              <p>Registrovanih kompanija</p>
            </div>
            <div class="icon">
                <i class="ion ion-briefcase"></i>
            </div>
          </div>
        </div>
       
        <div class="col-lg-4 col-xs-7 well">
          <!-- mala kutija -->
          <div class="small-box bg-yellow">
            <div class="inner">
             <?php
                      $sql = "SELECT * FROM users WHERE resume!=''";
                      $result = $conn->query($sql);
                      if($result->num_rows > 0) {
                        $totalno = $result->num_rows;
                      } else {
                        $totalno = 0;
                      }
                    ?>
              <h3><?php echo $totalno; ?></h3>

              <p>CV</p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-list"></i>
            </div>
          </div>
        </div>
       
        <div class="col-lg-5 col-lg-8 well ">
          <!-- mala kutija -->
          <div class="small-box bg-red well">
            <div class="inner">
               <?php
                      $sql = "SELECT * FROM users WHERE active='1'";
                      $result = $conn->query($sql);
                      if($result->num_rows > 0) {
                        $totalno = $result->num_rows;
                      } else {
                        $totalno = 0;
                      }
                    ?>
              <h3><?php echo $totalno; ?></h3>

              <p>Aktivnih korisnika</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-stalker"></i>
            </div>
          </div>
        </div>
      </div>
      </div>
    </section>

    <section id="about" class="content-header">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center latest-job margin-bottom-20">
            <h1>O nama</h1>                      
          </div>
        </div>
        <div class="row">
          <div class="col-md-8">
            <img src="img/ab.jpg" class="img-circle">
          </div>
		  </div>
		   <div class="row">
          <div class="center">    
            <strong><p> Ovaj sajt za zapošljavanje u Srbiji, namenjen je poslodavcima i ljudima koji traže posao.
Pruža Vam informacije o ponudi i tražnji radnih mesta, podstiče pripremu ljudi za nalaženje odgovarajućeg posla i efikasnim metodama ih povezuje sa poslodavcima koji traže kvalitetne radnike.Ovaj sajt je namenjen ljudima koji žele da započnu svoju novu karijeru, kao i poslodavcima koji traže kompetentan radni kadar.</p>
          </strong></div>
        </div>
      </div>
    </section>

  </div>

  <div class="control-sidebar-bg"></div>

</div>
<!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-navy">
  <h2 class="text-center">KONTAKT</h2>
  <div class="row">
    <div class="col-sm-5">
      <p>Kontaktirajte nas (u narednih 24 sata dobijate odgovor).</p>
      <p><span class="glyphicon glyphicon-map-marker"></span> Kragujevac, Srbija</p>
      <p><span class="glyphicon glyphicon-phone"></span> +381 1515151515</p>
      <p><span class="glyphicon glyphicon-envelope"></span> email123@gmail.com</p>
    </div>
    <div class="col-sm-4 slideanim">
      <div class="row">
        <div class="col-sm-4 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default pull-right" type="submit">Send</button>
        </div>
      </div>
    </div>
  </div>
</div>


<footer class="container-fluid text-center">
  <a href="index.php" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
</p>
</footer>


<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='index.php']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
<!-- jQuery 3 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>
</body>
</html>
