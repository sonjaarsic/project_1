<?php

session_start();

require_once("db.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Oglasi za posao</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="css/AdminLTE.min.css">
  <link rel="stylesheet" href="css/_all-skins.min.css">
  <link rel="stylesheet" href="css/custom.css">
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<style>
  body {
    font: 400 15px Lato, sans-serif;
    line-height: 2;
    color: #818181;
  }
  
 
 
  .navbar {
    margin-bottom: 0;
    background-color: #00cca3;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
    color: #f4511e !important;
    background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
  }

  }
   well {
      background-color: #555;
      color: white;
      padding: 15px;
    }
  </style>
</head>
<body class="hold-transition skin-red sidebar-mini">
<div class="wrapper">


<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>

 <a class="navbar-brand" href="index.php">Oglasi za posao</a>
	  <ul class="nav navbar-nav " >
        <li>
        <?php
          if(isset($_SESSION["id_admin"]))
          {
          $reference="admin/dashboard.php";
          }
          else { $reference="jobs.php";}
          ?>
          <a href=<?php echo $reference; ?>>Poslovi</a></li>        
      </ul>
   
    </div>
 
  </div>
</nav>

</header>



  <div class="container-fluid text-center" style="margin-left: 0px;">

    <section id="candidates" class="content-header">
      <div class="container">
        <div class="row">

          <div class="col-md-16 bg-white padding-5">
            
			<!-- Container (Services Section) -->
<div id="services" class="container-fluid text-center">
  <h2>Detalji o kompaniji</h2>
  <h3><a href="<?php echo $row['website']; ?>">Veb sajt</a></h3>
  <br>
 <div class="row">
              <form action="update-company.php" method="post" enctype="multipart/form-data">
                <?php
                  $sql = "SELECT * FROM company WHERE id_company='$_GET[id]'";
                  $result = $conn->query($sql);

                  if($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                ?>
                <div class="col-md-12 latest-job ">
                  <div class="form-group">
                   
                    <h3 style="text-align:center;"><?php echo $row['companyname']; ?></h3><br>
					      <?php if($row['logo'] != "") { ?>
                    <p style="text-align: center;"><img src="uploads/logo/<?php echo $row['logo']; ?>" class="img-responsive center" style="max-height: 200px; max-width: 200px;"></p>
                    <?php } ?>
                  </div>
                 
                    <br>
  <div class="row slideanim">
    <div class="col-sm-4">
      <span class="glyphicon  glyphicon-th-large logo-small"></span>
     <a href="<?php echo $row['website']; ?>"></a>
      <h4>Web sajt</h4>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon  glyphicon-envelope "></span>
      <h3><?php echo $row['email']; ?></h3>
      <h4>Email adresa</h4>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-home logo-small"></span>
      <h3><?php echo $row['country']; ?></h3>
      <h4>Drzava</h4>
    </div>
  </div>
  <br><br>
  <div class="row slideanim">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-phone logo-small"></span>
      <h3 ><?php echo $row['contactno']; ?></h3>
      <h4>Kontakt telefon</h4>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-certificate logo-small"></span>
      <h3><?php echo $row['city']; ?></h3>
      <h4>Grad</h4>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-wrench logo-small"></span>
      <h4 ><?php echo $row['aboutme']; ?></h4>
      <h4>O nama</h4>
    </div>
	       
                  <div class="pull-right">
                    <a href="jobs.php" class="btn btn-default btn-lg btn-flat margin-top-20"><i class="fa fa-arrow-circle-left"></i> Nazad</a>
                  </div>
           
  </div>
</div>
           
       
                    <?php
                    }
                  }
                ?>  
              </form>
            </div>
            <?php if(isset($_SESSION['uploadError'])) { ?>
            <div class="row">
              <div class="col-md-12 text-center">
                <?php echo $_SESSION['uploadError']; ?>
              </div>
            </div>
            <?php unset($_SESSION['uploadError']); } ?>
            
            <?php 
              if(isset($_SESSION["id_user"]) && empty($_SESSION['companyLogged'])) { ?>
              <div class="col-md-12 bg-white padding-2">
              <hr>
			  
			  
			  
           
              <div class="row">
                <form method="post" action="user/addcomment.php?id_company=<?php echo $_GET['id']; ?> ">
                  <div class="col-md-12 latest-job ">
				     <div class="form-group">
                     <select id='rating'name='rating'>
              <option value="1"> 1 </option>
              <option value="2"> 2 </option>
              <option value="3"> 3 </option>
              <option value="4"> 4 </option>
              <option value="5"> 5 </option>
            </select>
			<h4> <strong>Ocena </strong></h4>
                    </div>
					 <div class="form-group">
                      <textarea class="form-control input-lg" id="ime" name="ime" placeholder="Vaše ime"></textarea>
                    </div>
                    <div class="form-group">
                      <textarea class="form-control input-lg" id="comment" name="comment" placeholder="Vaš komentar ovde"></textarea>
                    </div>
            
                    <div class="form-group">
                      <button type="submit" class="btn btn-flat btn-primary">Pošalji</button>
                    </div>
                  </div>
                </form>
            </div>
            
          </div>
			<?php } ?>

          </div>
        </div>
      </div>
    </section>
    

  </div>

  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../js/adminlte.min.js"></script>
</body>
</html>
